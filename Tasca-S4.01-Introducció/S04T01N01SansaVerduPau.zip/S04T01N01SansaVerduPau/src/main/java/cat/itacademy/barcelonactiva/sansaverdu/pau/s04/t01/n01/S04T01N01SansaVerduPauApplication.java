package cat.itacademy.barcelonactiva.sansaverdu.pau.s04.t01.n01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N01SansaVerduPauApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N01SansaVerduPauApplication.class, args);
	}

}
